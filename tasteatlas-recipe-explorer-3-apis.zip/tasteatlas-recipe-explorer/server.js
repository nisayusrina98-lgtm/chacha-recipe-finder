// TasteAtlas Custom API (unique API) + static website server. Uses Node.js built-ins only.
const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const recipes = [
 {id:1,name:'Malaysian Coconut Rice',cuisine:'Malaysian',category:'Main dish',time:'35 min',description:'Fragrant coconut rice served with sambal, cucumber, egg and crunchy sides.',image:'https://images.unsplash.com/photo-1596560548464-f010549b84d7?auto=format&fit=crop&w=900&q=80',ingredients:['Rice','Coconut milk','Pandan leaves','Sambal','Cucumber','Egg','Peanuts'],instructions:'1. Rinse the rice. 2. Cook with coconut milk and water until fluffy. 3. Serve with sambal, cucumber, egg and peanuts.'},
 {id:2,name:'Malaysian Grilled Meat Skewers',cuisine:'Malaysian',category:'Main dish',time:'40 min',description:'Grilled marinated skewers served with peanut dipping sauce.',image:'https://images.unsplash.com/photo-1529042410759-befb1204b468?auto=format&fit=crop&w=900&q=80',ingredients:['Chicken or beef','Turmeric','Coriander','Garlic','Soy sauce','Peanut sauce'],instructions:'1. Cut meat into small pieces. 2. Marinate with spices. 3. Thread onto skewers and grill until fully cooked. 4. Serve with peanut sauce.'},
 {id:3,name:'Malaysian Flatbread with Curry',cuisine:'Malaysian',category:'Snack',time:'30 min',description:'Golden flatbread served with warm curry sauce.',image:'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80',ingredients:['Flour','Water','Salt','Oil','Curry sauce'],instructions:'1. Mix flour, salt and water into a dough. 2. Rest and shape the dough. 3. Flatten and cook on a hot pan until golden. 4. Serve with curry.'},
 {id:4,name:'Japanese Teriyaki Chicken',cuisine:'Japanese',category:'Main dish',time:'30 min',description:'Sweet and savoury glazed chicken served with rice.',image:'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=900&q=80',ingredients:['Chicken','Soy sauce','Mirin','Honey','Rice','Spring onion'],instructions:'1. Mix soy sauce, mirin and honey. 2. Cook chicken in a pan. 3. Add sauce and simmer until glossy and chicken is cooked. 4. Serve with rice.'},
 {id:5,name:'Italian Spaghetti with Tomato Sauce',cuisine:'Italian',category:'Main dish',time:'25 min',description:'Classic spaghetti tossed in a rich tomato sauce.',image:'https://images.unsplash.com/photo- pasta',ingredients:['Spaghetti','Tomatoes','Garlic','Olive oil','Basil','Parmesan'],instructions:'1. Cook spaghetti according to packet instructions. 2. Sauté garlic in olive oil. 3. Add tomatoes and simmer. 4. Toss with pasta and basil.'},
 {id:6,name:'Indian Butter Chicken',cuisine:'Indian',category:'Main dish',time:'45 min',description:'Tender chicken in a creamy tomato and spice sauce.',image:'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=900&q=80',ingredients:['Chicken','Tomatoes','Cream','Butter','Garam masala','Garlic','Ginger'],instructions:'1. Cook garlic and ginger in butter. 2. Add spices and tomatoes. 3. Add chicken and cook through. 4. Stir in cream and simmer.'},
 {id:7,name:'Mexican Chicken Tacos',cuisine:'Mexican',category:'Main dish',time:'25 min',description:'Seasoned chicken served in tortillas with fresh toppings.',image:'https://images.unsplash.com/photo-155150 A-8432-5e8b2f4f4f4f',ingredients:['Chicken','Tortillas','Paprika','Cumin','Lettuce','Tomato','Lime'],instructions:'1. Season and cook chicken fully. 2. Warm tortillas. 3. Fill with chicken and toppings. 4. Finish with lime.'},
 {id:8,name:'Korean Mixed Rice Bowl',cuisine:'Korean',category:'Main dish',time:'35 min',description:'Rice bowl with vegetables, egg and a spicy-savoury sauce.',image:'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=900&q=80',ingredients:['Rice','Carrot','Spinach','Mushrooms','Egg','Gochujang'],instructions:'1. Cook rice. 2. Prepare vegetables separately. 3. Top rice with vegetables and cooked egg. 4. Serve with gochujang sauce.'}
];
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.txt':'text/plain; charset=utf-8','.json':'application/json; charset=utf-8'};
function send(res,status,data,type='application/json; charset=utf-8'){res.writeHead(status,{'Content-Type':type,'Access-Control-Allow-Origin':'*'});res.end(type.startsWith('application/json')?JSON.stringify(data):data)}
const server=http.createServer((req,res)=>{
 const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
 if(url.pathname==='/api/recipes' || url.pathname.startsWith('/api/recipes/')){
   let results=[...recipes];
   const id=url.pathname.match(/^\/api\/recipes\/(\d+)$/);
   if(id){const found=recipes.find(r=>r.id===Number(id[1]));return found?send(res,200,found):send(res,404,{error:'Recipe not found'});}
   const q=(url.searchParams.get('q')||'').toLowerCase();
   const ingredient=(url.searchParams.get('ingredient')||'').toLowerCase();
   const cuisine=(url.searchParams.get('cuisine')||'').toLowerCase();
   if(q)results=results.filter(r=>(r.name+' '+r.description+' '+r.ingredients.join(' ')).toLowerCase().includes(q));
   if(ingredient)results=results.filter(r=>r.ingredients.some(i=>i.toLowerCase().includes(ingredient)));
   if(cuisine)results=results.filter(r=>r.cuisine.toLowerCase()===cuisine);
   return send(res,200,{count:results.length,recipes:results});
 }
 let pathname=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname);
 const file=path.resolve(ROOT,'.'+pathname);
 if(!file.startsWith(ROOT)){return send(res,403,{error:'Forbidden'});}
 fs.readFile(file,(err,body)=>{if(err)return send(res,404,{error:'File not found'});send(res,200,body,types[path.extname(file)]||'application/octet-stream');});
});
server.listen(PORT,()=>console.log(`TasteAtlas running at http://localhost:${PORT}`));

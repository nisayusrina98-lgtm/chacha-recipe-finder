TASTEATLAS — RECIPE EXPLORER (3 API VERSION)

REQUIREMENT: 1 unique API + 2 shared APIs
1. Unique API: TasteAtlas Custom API, developed in server.js. Routes: GET /api/recipes, GET /api/recipes?q=chicken, GET /api/recipes?cuisine=Malaysian, GET /api/recipes?ingredient=rice, GET /api/recipes/1. It returns a JSON collection curated for this project.
2. Shared API: TheMealDB, used for live recipe search, cuisine filters and details. https://www.themealdb.com/api.php
3. Shared API: Edamam Recipe Search API, used for recipe search and available nutrition information. https://developer.edamam.com/edamam-recipe-api

RUN LOCALLY
1. Install Node.js 18 or newer.
2. Open this folder in VS Code.
3. Open Terminal > New Terminal.
4. Run: npm start
5. Open http://localhost:3000 in your browser. Do not use Live Server for this version because the unique API route is provided by server.js.

USE THE UNIQUE API
In the website, scroll to “Choose your recipe API” and select “TasteAtlas Custom API — unique API”. It uses /api/recipes served by server.js. Search food or choose a cuisine.

USE THEMEALDB
Select “TheMealDB — shared API”. The demo endpoints used here do not need an API key.

USE EDAMAM
Select Edamam and enter your own App ID and App Key from https://developer.edamam.com/edamam-recipe-api, then save settings. Access and features depend on your Edamam plan. For a public deployment, move credentials to server-side environment variables instead of putting them in browser code.

EXAMPLE ENDPOINTS AND JSON
Unique API endpoint:
GET http://localhost:3000/api/recipes?cuisine=Malaysian
Example response:
{"count":1,"recipes":[{"id":1,"name":"Malaysian Coconut Rice","cuisine":"Malaysian"}]}

Shared API 1 (TheMealDB):
GET https://www.themealdb.com/api/json/v1/1/search.php?s=chicken
Example response shape:
{"meals":[{"strMeal":"Chicken recipe name","strMealThumb":"https://...","idMeal":"..."}]}

Shared API 2 (Edamam):
GET https://api.edamam.com/api/recipes/v2?type=public&q=chicken&app_id=YOUR_APP_ID&app_key=YOUR_APP_KEY
Example response shape:
{"hits":[{"recipe":{"label":"Recipe name","image":"https://...","calories":123}}]}

NOTES
- TasteAtlas Custom API is a small project-specific API built in server.js, with curated data stored in that file (not a third-party API).
- TheMealDB and Edamam are external shared APIs.
- Edamam requires credentials; you can still demonstrate the custom API and TheMealDB without them.
- API availability, response data, and rate limits depend on the provider.
